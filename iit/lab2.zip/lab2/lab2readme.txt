README FILE - LAB 2

Name: Catherine Chu 
ITWS Section: 1

This was my first time coding in HTML and I found the formatting part of the the design process especially difficult. I still struggle with indentation and how to make the source code easier to read. It took a lot of trial and error to understand how the margins worked, as well as how the blocks worked. However, after a several tinkers and google searches, I finally got the hang of the basics of HTML. 

