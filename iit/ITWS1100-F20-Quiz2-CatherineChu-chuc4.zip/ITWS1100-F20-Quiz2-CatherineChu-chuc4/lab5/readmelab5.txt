INTRODUCTION TO ITWS - LAB 5

NAME: Catherine Chu
Section: 1

I learned a lot about javascript in this lab, and how HTML, CSS, and Javascript link together. I especially had trouble trying to fix crime 4, since I had to do a bit of research on how to change the background color of the box, as well as using the "focus" keyword. 

Link to personal website: https://afsws.rpi.edu/AFS/home/29/chuc4/public_html/iit/mysite/