$(document).ready(function() {  
    $('a#is_logged').click(function() {
        if($('a#is_logged').text() == "Log Out") {
            $('a#is_logged').text("Log In");
            window.location.replace('index.html'); 
        }
    });

    $('#login_button').click(function() {
        $.ajax({
            type: "GET", 
            url: "resources/usersXML.xml", 
            dataType: "xml", 
            success: function(xml){
                var xml_doc = xml.responseXML;
                $(xml).find('user').each(function() {
                    var username = $(this).find('userid').text(); 
                    var password = $(this).find('password').text();
                    if(username == $('#userid').val() && password == $('#pass').val()) {
                        $('a#is_logged').text("Log Out");
                        window.location.replace('index.html'); 
                    }
                    else {
                        alert("Incorret Login Info"); 
                        window.location.replace('index.html'); 
                    }
                });
            }
        });
    });
});