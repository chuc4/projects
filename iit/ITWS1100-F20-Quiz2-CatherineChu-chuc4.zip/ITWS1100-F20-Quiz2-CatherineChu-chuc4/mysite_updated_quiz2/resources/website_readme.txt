INTRODUCTION TO ITWS - My Personal Website 

Name: Catherine Chu 
Section: 1

This is a personal website holding all of the past projects I have done for the class Introduction to ITWS at RPI. Everything matches the description and there is only one known bug. The "log in" button will not change to "log out" and perform the required actions. I will still continue to work on this bug. 

Github: chuc4
Discord: Cat#8373