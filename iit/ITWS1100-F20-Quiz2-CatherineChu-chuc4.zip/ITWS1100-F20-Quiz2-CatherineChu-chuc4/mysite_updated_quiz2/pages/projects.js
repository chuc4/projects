$(document).ready(function() {
    $.ajax({
       type: "GET",
       url: "projects.json",
       dataType: "json",
       success: function(responseData, status) {
          var output = "<ul>";
          var img_output = "<img";
          //create loop to iterate through json file
          $.each(responseData.projectsImage, function(i, item) {
            img_output += ' src="'+item.imgURL+'" alt="'+item.imgName+'" width="'+item.imgWidth+'" height="'+item.imgHeight+'"';
         });
         img_output+="/>";
         $('#projectImages').html(img_output);
         
          $.each(responseData.menuItem, function(i, item) {
            output += '<li><a href="'+item.menuURL+'">"'+item.menuName+ " "+item.menuDesc+'"</a></li>';
          });
          output +="</ul>";
          $('#projects').html(output);
    }
 });
}); 