$(document).ready(function() {
    $.ajax({
        type: "GET",
        url: "preferences.xml",
        dataType: "xml", 
        success: function(xml){
            var xml_doc = xml.responseXML;
            var output = "<a href="; 
            $(xml).find('file').each(function() {
                var name = $(this).find('name').text();
                var filename = $(this).find('file_name').text(); 
                output += filename + ">" + name;
            });
            output += "</a>";
            $('#readme').html(output);

            output = "<img src=";
            $(xml).find('img').each(function() {
                var name = $(this).find('image_name').text();
                var url = $(this).find('url').text(); 
                var w = $(this).find('width').text(); 
                var h = $(this).find('height').text(); 

                output += url + " width=" + w + " height=" + h;
            });
            output += ">";
            $('#header_image').html(output);
        }

    });
});