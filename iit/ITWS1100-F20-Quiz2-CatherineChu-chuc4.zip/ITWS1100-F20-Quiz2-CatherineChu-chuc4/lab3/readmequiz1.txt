QUIZ 1 - INTRODUCTION TO ITWS

Name: Catherine Chu
Section: 1

I added two extra pages that describe the two labs that were poasted on the website. This required an extra few folders in the site map, projects content and photos. The folder projects content has all the relocated lab solutions files, while the descriptions of each lab will now be in the same folder as projects.html. The photos folder holds the resume photo that was added to lab 2.

The logic and UI are pretty straight forward and the website is relatively easy to use. The links posted on the menu bar will direct you to the respect html files. The lab links on the projects page will now direct you to the lab descriptions before going to the lab solutions and code. 