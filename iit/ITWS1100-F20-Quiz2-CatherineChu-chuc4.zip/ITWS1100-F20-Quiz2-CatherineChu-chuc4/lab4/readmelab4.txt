INTRODUCTION TO ITWS - Lab 4 

Name: Catherine Chu 
Section: 1

This lab was the first time I learned XML, using both Atom and RSS. However, after some thought the lab was pretty straightforward, thanks to the template provided. 

Link: https://afsws.rpi.edu/AFS/home/29/chuc4/public_html/iit/lab3/mysite/pages/projects.html