INTRODUCTION TO ITWS - LAB 6

NAME: Catherine Chu
Section: 1

I learned a lot about jquery and how to connect all these different languages, jquery, javascript, HTML, and CSS together. I did a lot of research to understand more about jquery and the differences between that and javascript. While I still prefer using javascript, I see the benefits of jquery and why it's such a well-known language today.  

Link to personal website: https://afsws.rpi.edu/AFS/home/29/chuc4/public_html/iit/mysite_updated/