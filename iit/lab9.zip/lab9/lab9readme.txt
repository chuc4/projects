INTRODUCTION TO ITWS - LAB 9

Name: Catherine Chu 
Section: 1

The parsing took longer than usual because I had to get used to the syntax used. I also had trouble deal with files in different folders. I've tried several ways in the menuItem URL to access files in separate folders, but it seems that it can only access into 2 folders maximum. Therefore, I had to copy all my previous projects into a projects folder. 

Discord: Cat#8373 
GitHub: chuc4 (updated in the quiz1 repo) 