INTRODUCTION TO ITWS - LAB 3

Name: Catherine Chu 
Section: 1

In this lab I created two pages: the home page and the projects page. I created one CSS file to design the home page. The horizontal menu has effects added when the mouse hovers over the link. I also added a fixed footer at the bottom of the website. Finally, I added a header image and designed the home page. 


URL: https://afsws.rpi.edu/AFS/home/29/chuc4/public_html/iit/